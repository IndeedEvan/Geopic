package com.mycompany.mavenproject1;

import org.jxmapviewer.viewer.DefaultWaypoint;
import org.jxmapviewer.viewer.GeoPosition;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;

/**
 * A waypoint that is represented by a button on the map.
 *
 * @author Daniel Stahr
 */
public class SwingWaypoint extends DefaultWaypoint {
    private final JButton button;
    private final String text;
    private final ImageIcon image;

    public SwingWaypoint(String text, GeoPosition coord,ImageIcon img) {
        super(coord);
        this.text = text;
        Image scaledInstance = img.getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH);
            this.image=new ImageIcon(scaledInstance);
        button = new JButton(text.substring(0, 1) ,image);
        button.setSize(30, 30);
        button.addMouseListener(new SwingWaypointMouseListener());
        button.setBorderPainted(false);
        button.setBorder(null);
        button.setMargin(new Insets(0, 0, 0, 0));
        button.setContentAreaFilled(false);
        button.setVisible(true);
    }
    
    
 

    JButton getButton() {
        return button;
    }

    private class SwingWaypointMouseListener implements MouseListener {

        @Override
        public void mouseClicked(MouseEvent e) {
            
            JOptionPane.showMessageDialog(button, "You clicked on " + text);
        }

        @Override
        public void mousePressed(MouseEvent e) {
        }

        @Override
        public void mouseReleased(MouseEvent e) {
        }

        @Override
        public void mouseEntered(MouseEvent e) {
        }

        @Override
        public void mouseExited(MouseEvent e) {
        }
    }
}
