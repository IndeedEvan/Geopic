/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

import com.drew.imaging.ImageProcessingException;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Point2D;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import javax.swing.event.MouseInputListener;
import org.jxmapviewer.JXMapViewer;
import org.jxmapviewer.VirtualEarthTileFactoryInfo;
import org.jxmapviewer.input.CenterMapListener;
import org.jxmapviewer.input.PanKeyListener;
import org.jxmapviewer.input.PanMouseInputListener;
import org.jxmapviewer.input.ZoomMouseWheelListenerCenter;
import org.jxmapviewer.viewer.DefaultTileFactory;
import org.jxmapviewer.viewer.GeoPosition;
import org.jxmapviewer.viewer.LocalResponseCache;
import org.jxmapviewer.viewer.TileFactoryInfo;
import org.jxmapviewer.viewer.WaypointPainter;

/**
 *
 * @author Ehsan
 */
public class Init_Map3 extends JXMapViewer {
    public JXMapViewer mapViewer;
    public static ArrayList<SwingWaypoint_Old> swing;
    
   

    
    public Init_Map3() throws ImageProcessingException, IOException, ClassNotFoundException {
        final GeoPosition gp = new GeoPosition(43.9307939,2.1282176); 
  //    System.out.println(this.getZoomInAction().);

	TileFactoryInfo veInfo = new VirtualEarthTileFactoryInfo(VirtualEarthTileFactoryInfo.MAP);
        DefaultTileFactory tileFactory = new DefaultTileFactory(veInfo);
        setTileFactory(tileFactory);
         ////////////////////
        File cacheDir = new File(System.getProperty("user.home") + File.separator + ".jxmapviewer2");
        LocalResponseCache.installResponseCache(veInfo.getBaseURL(), cacheDir, false);
        ////////////////////
       

        // Setup JXMapViewer
        mapViewer = this.mapViewer;
        mapViewer.setTileFactory(tileFactory);
        swing=new ArrayList<SwingWaypoint_Old>();
      //  ImageMeta ima;
        ArrayList<ImageMeta> imgmeta=new ArrayList<>();
      //  GeoPosition geo = null;
      
      //////// get from data base
    Connection c = null;
    Statement stmt = null;
    try {
      Class.forName("org.sqlite.JDBC");
      c = DriverManager.getConnection("jdbc:sqlite:test.db");
      c.setAutoCommit(false);
      

      stmt = c.createStatement();
      ResultSet rs = stmt.executeQuery( "SELECT distinct IMG_PATH.IMG_PATH, IMG_GPS.IMG_LAT,IMG_GPS.IMG_LONG FROM IMG_PATH, IMG_GPS WHERE IMG_PATH.IMG_ID=IMG_GPS.IMG_ID;" );
      String path;
      GeoPosition geos;
      ImageMeta img;
      while ( rs.next() ) {
         //int id = rs.getInt("id");
         path=rs.getString("IMG_PATH");
   
         geos=new GeoPosition(rs.getDouble("IMG_LAT"),rs.getDouble("IMG_LONG"));
         //System.out.println(geos+"   first  ");
        
         img=new ImageMeta(new File(path),geos);
         imgmeta.add(img);
      }
      //System.out.println(imgmeta.size());
      rs.close();
      stmt.close();
     // System.out.println("Opened database successfully");
      c.close();
    } catch ( ImageProcessingException | IOException | ClassNotFoundException | SQLException e ) {
      System.err.println( e.getClass().getName() + ": " + e.getMessage() );
      //System.exit(0);
    }
    //System.out.println("Operation done successfully");
  
    
        for (ImageMeta ima:imgmeta) {
            if (ima.is_taged()) {
            swing.add(new SwingWaypoint_Old(ima.GetImgName(),ima.getGPS(),ima.GetImg()));
            } 
        }
        
               
       // Set<SwingWaypoint> waypoints = new HashSet<SwingWaypoint>(Arrays.asList(
                
        if (swing.isEmpty()) {
          
            mapViewer.setZoom(17);
        } else {
            mapViewer.setCenterPosition(swing.get(0).getPosition());
            mapViewer.setZoom(14);
            }
        

        MouseInputListener mia = new PanMouseInputListener(mapViewer);
        mapViewer.addMouseListener(mia);
        mapViewer.addMouseMotionListener(mia);
        mapViewer.addMouseListener(new CenterMapListener(mapViewer));
        mapViewer.addMouseWheelListener(new ZoomMouseWheelListenerCenter(mapViewer));
        mapViewer.addKeyListener(new PanKeyListener(mapViewer));
       // final JToolTip tooltip = new JToolTip();
       // tooltip.setTipText("Java");
       // tooltip.setComponent(this.getMainMap());
       // this.getMainMap().add(tooltip);
        this.addMouseMotionListener(new MouseMotionListener() {
            @Override
            public void mouseDragged(MouseEvent e) { 
                // ignore
                
            }

            @Override
            public void mouseMoved(MouseEvent e)
            {
                JXMapViewer map =Init_Map3.this.mapViewer;

                // convert to world bitmap
                Point2D worldPos = map.getTileFactory().geoToPixel(gp, map.getZoom());

                // convert to screen
                Rectangle rect = map.getViewportBounds();
                int sx = (int) worldPos.getX() - rect.x;
                int sy = (int) worldPos.getY() - rect.y;
                Point screenPos = new Point(sx, sy);

                // check if near the mouse 
                /*
                if (screenPos.distance(e.getPoint()) < 20)
                {
                    screenPos.x -= tooltip.getWidth() / 2;

                    tooltip.setLocation(screenPos);
                    tooltip.setVisible(true);
                }
                else
                {
                    tooltip.setVisible(false);
                } */
            }
            });
        // Create waypoints from the geo-positions
       
       /* Set<SwingWaypoint> waypoints = new HashSet<SwingWaypoint>(Arrays.asList(
                new SwingWaypoint("Frankfurt", frankfurt, new ImageIcon("/Users/Ehsan/NetBeansProjects/Geopic/mavenproject1/src/main/java/com/mycompany/mavenproject1/waypoint_white.jpg")),
                new SwingWaypoint("Wiesbaden", wiesbaden, new ImageIcon("/Users/Ehsan/NetBeansProjects/Geopic/mavenproject1/src/main/java/com/mycompany/mavenproject1/waypoint_white.png")),
                new SwingWaypoint("Mainz", mainz, new ImageIcon("/Users/Ehsan/Desktop/test.jpg")),
                new SwingWaypoint("Darmstadt", darmstadt, new ImageIcon("/Users/Ehsan/NetBeansProjects/Geopic/mavenproject1/src/main/java/com/mycompany/mavenproject1/waypoint_white1.png"))));
                //new SwingWaypoint("Offenbach", offenbach, new ImageIcon("/Users/Ehsan/NetBeansProjects/Geopic/mavenproject1/src/main/java/com/mycompany/mavenproject1/waypoint_white.jpg")));
             */   Set<SwingWaypoint_Old> waypoints = new HashSet<SwingWaypoint_Old>(swing);
        // Set the overlay painter
        WaypointPainter<SwingWaypoint_Old> swingWaypointPainter = new SwingWaypointOverlayPainter_Old();
        swingWaypointPainter.setWaypoints(waypoints);
        mapViewer.setOverlayPainter(swingWaypointPainter);

        // Add the JButtons to the map viewer
        for (SwingWaypoint_Old w : waypoints) {
            mapViewer.add(w.getButton());    
        }
       
        //this.getMiniMap().setVisible(false);
      
    }
}
