/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

import com.drew.imaging.ImageProcessingException;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Point2D;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import javax.swing.ImageIcon;
import javax.swing.event.MouseInputListener;
import org.jxmapviewer.JXMapKit;
import org.jxmapviewer.JXMapViewer;
import org.jxmapviewer.VirtualEarthTileFactoryInfo;
import org.jxmapviewer.input.CenterMapListener;
import org.jxmapviewer.input.PanKeyListener;
import org.jxmapviewer.input.PanMouseInputListener;
import org.jxmapviewer.input.ZoomMouseWheelListenerCenter;
import org.jxmapviewer.viewer.DefaultTileFactory;
import org.jxmapviewer.viewer.GeoPosition;
import org.jxmapviewer.viewer.LocalResponseCache;
import org.jxmapviewer.viewer.TileFactoryInfo;
import org.jxmapviewer.viewer.WaypointPainter;

/**
 *
 * @author Ehsan
 */
public class Init_Map3 extends JXMapKit {

    
    public Init_Map3(File[] files) throws ImageProcessingException, IOException, ClassNotFoundException {
        final GeoPosition gp = new GeoPosition(43.9307939,2.1282176); 
        

	TileFactoryInfo veInfo = new VirtualEarthTileFactoryInfo(VirtualEarthTileFactoryInfo.MAP);
        DefaultTileFactory tileFactory = new DefaultTileFactory(veInfo);
        setTileFactory(tileFactory);
         ////////////////////
        File cacheDir = new File(System.getProperty("user.home") + File.separator + ".jxmapviewer2");
        LocalResponseCache.installResponseCache(veInfo.getBaseURL(), cacheDir, false);
        ////////////////////
       

        // Setup JXMapViewer
        JXMapViewer mapViewer = this.getMainMap();
        mapViewer.setTileFactory(tileFactory);
        ArrayList<SwingWaypoint> swing=new ArrayList<SwingWaypoint>();
        ImageMeta ima;
        ArrayList<String> paths=new ArrayList<>();
      //  GeoPosition geo = null;
      
      //////// get from data base
     Connection c = null;
    Statement stmt = null;
    try {
      Class.forName("org.sqlite.JDBC");
      c = DriverManager.getConnection("jdbc:sqlite:test.db");
      c.setAutoCommit(false);
      System.out.println("Opened database successfully");

      stmt = c.createStatement();
      ResultSet rs = stmt.executeQuery( "SELECT * FROM IMG_PATH;" );
      while ( rs.next() ) {
         //int id = rs.getInt("id");
         paths.add(rs.getString("IMG_PATH"));
        /* int age  = rs.getInt("age");
        // String  address = rs.getString("address");
        // float salary = rs.getFloat("salary");
         System.out.println( "ID = " + id );
         System.out.println( "NAME = " + name );
         System.out.println( "AGE = " + age );
         System.out.println( "ADDRESS = " + address );
         System.out.println( "SALARY = " + salary );
         System.out.println(); */
      }
      rs.close();
      stmt.close();
      c.close();
    } catch ( Exception e ) {
      System.err.println( e.getClass().getName() + ": " + e.getMessage() );
      System.exit(0);
    }
    System.out.println("Operation done successfully");
  
    
    
    
        for (File f:files) {
            ima=new ImageMeta(f);
            if (ima.is_taged()) {
            GeoPosition geo=new GeoPosition(ima.GetGPS_Data().get(0).getLatitude(),ima.GetGPS_Data().get(0).getLongitude());
            String str=ima.GetImgName();
            ImageIcon img=ima.img;
            
            swing.add(new SwingWaypoint(str,geo,img));
            } 
        }
        
               
       // Set<SwingWaypoint> waypoints = new HashSet<SwingWaypoint>(Arrays.asList(
                
                

        mapViewer.setZoom(15);
        mapViewer.setCenterPosition(gp);

        MouseInputListener mia = new PanMouseInputListener(mapViewer);
        mapViewer.addMouseListener(mia);
        mapViewer.addMouseMotionListener(mia);
        mapViewer.addMouseListener(new CenterMapListener(mapViewer));
        mapViewer.addMouseWheelListener(new ZoomMouseWheelListenerCenter(mapViewer));
        mapViewer.addKeyListener(new PanKeyListener(mapViewer));
       // final JToolTip tooltip = new JToolTip();
       // tooltip.setTipText("Java");
       // tooltip.setComponent(this.getMainMap());
       // this.getMainMap().add(tooltip);
        this.getMainMap().addMouseMotionListener(new MouseMotionListener() {
            @Override
            public void mouseDragged(MouseEvent e) { 
                // ignore
            }

            @Override
            public void mouseMoved(MouseEvent e)
            {
                JXMapViewer map = Init_Map3.this.getMainMap();

                // convert to world bitmap
                Point2D worldPos = map.getTileFactory().geoToPixel(gp, map.getZoom());

                // convert to screen
                Rectangle rect = map.getViewportBounds();
                int sx = (int) worldPos.getX() - rect.x;
                int sy = (int) worldPos.getY() - rect.y;
                Point screenPos = new Point(sx, sy);

                // check if near the mouse 
                /*
                if (screenPos.distance(e.getPoint()) < 20)
                {
                    screenPos.x -= tooltip.getWidth() / 2;

                    tooltip.setLocation(screenPos);
                    tooltip.setVisible(true);
                }
                else
                {
                    tooltip.setVisible(false);
                } */
            }
            });
        // Create waypoints from the geo-positions
       
       /* Set<SwingWaypoint> waypoints = new HashSet<SwingWaypoint>(Arrays.asList(
                new SwingWaypoint("Frankfurt", frankfurt, new ImageIcon("/Users/Ehsan/NetBeansProjects/Geopic/mavenproject1/src/main/java/com/mycompany/mavenproject1/waypoint_white.jpg")),
                new SwingWaypoint("Wiesbaden", wiesbaden, new ImageIcon("/Users/Ehsan/NetBeansProjects/Geopic/mavenproject1/src/main/java/com/mycompany/mavenproject1/waypoint_white.png")),
                new SwingWaypoint("Mainz", mainz, new ImageIcon("/Users/Ehsan/Desktop/test.jpg")),
                new SwingWaypoint("Darmstadt", darmstadt, new ImageIcon("/Users/Ehsan/NetBeansProjects/Geopic/mavenproject1/src/main/java/com/mycompany/mavenproject1/waypoint_white1.png"))));
                //new SwingWaypoint("Offenbach", offenbach, new ImageIcon("/Users/Ehsan/NetBeansProjects/Geopic/mavenproject1/src/main/java/com/mycompany/mavenproject1/waypoint_white.jpg")));
             */   Set<SwingWaypoint> waypoints = new HashSet<SwingWaypoint>(swing);
        // Set the overlay painter
        WaypointPainter<SwingWaypoint> swingWaypointPainter = new SwingWaypointOverlayPainter();
        swingWaypointPainter.setWaypoints(waypoints);
        mapViewer.setOverlayPainter(swingWaypointPainter);

        // Add the JButtons to the map viewer
        for (SwingWaypoint w : waypoints) {
           
            mapViewer.add(w.getButton());
            
        }
        this.getMiniMap().setVisible(false);
        //System.out.println(this.getZoomSlider().getValue());
        
    }
}
