
package com.mycompany.mavenproject1;

import java.awt.Color;
import java.io.File;

import org.jxmapviewer.viewer.DefaultWaypoint;
import org.jxmapviewer.viewer.GeoPosition;

/**
 * A waypoint that also has a color and a label
 * @author Martin Steiger
 */
public class MyWaypoint2 extends DefaultWaypoint
{
		private final String label;
	private final Color color;
        private final File file;

	/**
	 * @param label the text
	 * @param color the color
	 * @param coord the coordinate
	 */
	public MyWaypoint2(String label, Color color, GeoPosition coord,File f)
	{
		super(coord);
		this.label = label; 
		this.color = color; 
                this.file=f;
        }

	/**
	 * @return the label text
	 */
	public String getLabel()
	{
		return label;
	}

	/**
	 * @return the color
	 */
	public Color getColor()
	{
		return color;
	} 
        
        public File getFile()
	{
		return this.file;
	}

	
}
