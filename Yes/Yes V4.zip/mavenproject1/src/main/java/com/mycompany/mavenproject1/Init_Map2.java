/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

import java.awt.Color;
import java.io.File;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import javax.swing.event.MouseInputListener;
import org.jxmapviewer.JXMapViewer;
import org.jxmapviewer.VirtualEarthTileFactoryInfo;
import org.jxmapviewer.input.CenterMapListener;
import org.jxmapviewer.input.PanKeyListener;
import org.jxmapviewer.input.PanMouseInputListener;
import org.jxmapviewer.input.ZoomMouseWheelListenerCenter;
import org.jxmapviewer.viewer.DefaultTileFactory;
import org.jxmapviewer.viewer.GeoPosition;
import org.jxmapviewer.viewer.LocalResponseCache;
import org.jxmapviewer.viewer.TileFactoryInfo;
import org.jxmapviewer.viewer.WaypointPainter;

/**
 *
 * @author Ehsan
 */
public class Init_Map2 extends JXMapViewer {

    public Init_Map2() {
        
        
        //JXMapViewer mapViewer = new JXMapViewer();
        ///////
      //  TileFactoryInfo info = new OSMTileFactoryInfo();
	TileFactoryInfo veInfo = new VirtualEarthTileFactoryInfo(VirtualEarthTileFactoryInfo.MAP);
        ///////
        DefaultTileFactory tileFactory = new DefaultTileFactory(veInfo);
        
        
        this.setTileFactory(tileFactory);
        		// Setup local file cache
		File cacheDir = new File(System.getProperty("user.home") + File.separator + ".jxmapviewer2");
		LocalResponseCache.installResponseCache(veInfo.getBaseURL(), cacheDir, false);

                GeoPosition frankfurt = new GeoPosition(50,  7, 0, 8, 41, 0);
		GeoPosition wiesbaden = new GeoPosition(50,  5, 0, 8, 14, 0);
		GeoPosition mainz     = new GeoPosition(50,  0, 0, 8, 16, 0);
		GeoPosition darmstadt = new GeoPosition(49, 52, 0, 8, 39, 0);
		GeoPosition offenbach = new GeoPosition(50,  6, 0, 8, 46, 0);

		// Set the focus
		this.setZoom(10);
		this.setAddressLocation(frankfurt);
                MouseInputListener mia = new PanMouseInputListener(this);
		this.addMouseListener(mia);
		this.addMouseMotionListener(mia);
		this.addMouseListener(new CenterMapListener(this));
		this.addMouseWheelListener(new ZoomMouseWheelListenerCenter(this));
		this.addKeyListener(new PanKeyListener(this));
        
                Set<MyWaypoint2> waypoints = new HashSet<MyWaypoint2>(Arrays.asList(
				new MyWaypoint2("F",Color.CYAN, frankfurt,new File("/Users/Ehsan/NetBeansProjects/Geopic/mavenproject1/src/main/java/com/mycompany/mavenproject1/waypoint_white.jpg")),
				new MyWaypoint2("W",Color.BLUE, wiesbaden,new File("/Users/Ehsan/NetBeansProjects/Geopic/mavenproject1/src/main/java/com/mycompany/mavenproject1/waypoint_white.jpg")),
				new MyWaypoint2("M",Color.ORANGE, mainz,new File("/Users/Ehsan/NetBeansProjects/Geopic/mavenproject1/src/main/java/com/mycompany/mavenproject1/waypoint_white.jpg")),
				new MyWaypoint2("D",Color.GREEN, darmstadt,new File("/Users/Ehsan/NetBeansProjects/Geopic/mavenproject1/src/main/java/com/mycompany/mavenproject1/waypoint_white.jpg")),
				new MyWaypoint2("O",Color.BLACK, offenbach,new File("/Users/Ehsan/NetBeansProjects/Geopic/mavenproject1/src/main/java/com/mycompany/mavenproject1/waypoint_white1.png"))));
                
                // Create a waypoint painter that takes all the waypoints
		WaypointPainter<MyWaypoint2> waypointPainter = new WaypointPainter<MyWaypoint2>();
		waypointPainter.setWaypoints(waypoints);
          
                waypointPainter.setRenderer(new FancyWaypointRenderer(new File("/Users/Ehsan/NetBeansProjects/Geopic/mavenproject1/src/main/java/com/mycompany/mavenproject1/waypoint_white.jpg")));
		//waypointPainter.setRenderer(new FancyWaypointRenderer(new File("/Users/Ehsan/NetBeansProjects/Geopic/mavenproject1/src/main/java/com/mycompany/mavenproject1/waypoint_white1.png")));
              //  System.out.println(waypoints.iterator().next().getFile().getAbsolutePath());
		
                this.setOverlayPainter(waypointPainter);
                
              /*  Set<MyWaypoint> waypoints1 = new HashSet<MyWaypoint>(Arrays.asList(
				new MyWaypoint("F",Color.CYAN, frankfurt),
				new MyWaypoint("W",Color.BLUE, wiesbaden),
				new MyWaypoint("M",Color.ORANGE, mainz),
				new MyWaypoint("D",Color.GREEN, darmstadt),
				new MyWaypoint("O",Color.BLACK, offenbach)));
                
                // Create a waypoint painter that takes all the waypoints
		 WaypointPainter<MyWaypoint> waypointPainter1 = new WaypointPainter<MyWaypoint>();
		waypointPainter1.setWaypoints(waypoints1);
		waypointPainter1.setRenderer(new FancyWaypointRenderer(new File("/Users/Ehsan/NetBeansProjects/Geopic/mavenproject1/src/main/java/com/mycompany/mavenproject1/waypoint_white1.png")));
		
		this.setOverlayPainter(waypointPainter1); */
                
        
    
    }
}
